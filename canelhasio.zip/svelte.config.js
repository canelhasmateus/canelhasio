// svelte.config.js
const { typescript } = require('svelte-preprocess');

module.exports = {
	preprocess: [typescript(
        // { "tsconfigFile": "C:\\Users\\Lity\\Desktop\\workspace\\lity\\canelhasio\\packages\\tsconfig.json" }
    )]
};
