<svelte:options immutable={true}/>

<script lang="ts">

	export let circle

</script>

<circle bind:this={circle}>

</circle>
